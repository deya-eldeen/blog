import SwiftUI

struct AuthenticationView: View {
    @StateObject private var viewModel = AuthenticationViewModel()

    var body: some View {
        VStack {
            // Authentication Section
            Text("Login")
                .font(.largeTitle)
                .padding()

            TextField("Username", text: $viewModel.username)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())

            SecureField("Password", text: $viewModel.password)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())

            Button(action: {
                viewModel.authenticate()
            }) {
                Text("Login")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.blue)
                    .cornerRadius(10)
            }

            // Display authentication status
            if let success = viewModel.isAuthenticated {
                if success {
                    Text("Authenticated")
                        .foregroundColor(.green)
                } else {
                    Text("Not Authenticated")
                        .foregroundColor(.red)
                }
            } else {
                Text("") // Show empty string when no attempt has been made
            }

            Divider().padding()

            // Registration Section
            Text("Register")
                .font(.largeTitle)
                .padding()

            TextField("Username", text: $viewModel.registrationUsername)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())

            SecureField("Password", text: $viewModel.registrationPassword)
                .padding()
                .textFieldStyle(RoundedBorderTextFieldStyle())

            Button(action: {
                viewModel.register()
            }) {
                Text("Register")
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.green)
                    .cornerRadius(10)
            }

            // Display registration status
            if let success = viewModel.registrationSuccess {
                if success {
                    Text("Registration Successful!")
                        .foregroundColor(.green)
                } else {
                    Text("Registration Failed!")
                        .foregroundColor(.red)
                }
            } else {
                Text("") // Show empty string when no registration attempt has been made
            }
        }
        .padding()
    }
}
