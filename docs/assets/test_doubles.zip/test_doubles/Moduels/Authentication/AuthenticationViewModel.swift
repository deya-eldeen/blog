import Foundation

class AuthenticationViewModel: ObservableObject {

    @Published var username = ""
    @Published var password = ""
    @Published var isAuthenticated: Bool? = nil
    @Published var registrationUsername = ""
    @Published var registrationPassword = ""
    @Published var registrationSuccess: Bool? = nil

    let authenticator: UserManager
    
    init(authenticator: UserManager = UserManager()) {
        self.authenticator = authenticator
    }
    func authenticate() {
        isAuthenticated = authenticator.authenticate(username: username, password: password)
    }

    func register() {
        registrationSuccess = authenticator.register(username: registrationUsername, password: registrationPassword)
    }
}
