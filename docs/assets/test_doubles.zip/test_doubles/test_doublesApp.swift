import SwiftUI

@main
struct test_doublesApp: App {
    var body: some Scene {
        WindowGroup {
            AuthenticationView()
        }
    }
}
