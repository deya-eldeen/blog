import XCTest
@testable import test_doubles

class UserManagerTests: XCTestCase {
    
    func testAuthenticateWithCacheHit() {
        // Arrange
        let dummyLogger = DummyLogger()
        let stubCache = StubCache()
        let fakeDatabase = FakeDatabase()
        let spySecuritySystem = SpySecurityHelper()
        let mockNotificationService = MockNotificationService()
        
        let passwordHash = "hashed_password123"
        stubCache.storedData["john_doe"] = passwordHash
        
        let userManager = UserManager(logger: dummyLogger, cache: stubCache, database: fakeDatabase, securityHelper: spySecuritySystem, notificationService: mockNotificationService)
        
        // Act
        let result = userManager.authenticate(username: "john_doe", password: "password123")
        
        // Assert
        XCTAssertTrue(result)
        XCTAssertTrue(spySecuritySystem.verifyAttempt(username: "john_doe", success: true))
        XCTAssertTrue(mockNotificationService.verifyEmailSent(to: "john_doe", success: true))
        XCTAssertNil(fakeDatabase.getUserPasswordHash(username: "john_doe"), "Database should not be accessed")
    }
    
    func testAuthenticateWithCacheMissAndValidDatabaseUser() {
        // Arrange
        let dummyLogger = DummyLogger()
        let stubCache = StubCache() // Cache miss by default
        let fakeDatabase = FakeDatabase()
        let spySecuritySystem = SpySecurityHelper()
        let mockNotificationService = MockNotificationService()
        
        let passwordHash = "hashed_password123"
        fakeDatabase.addUser(username: "jane_doe", passwordHash: passwordHash)
        
        let userManager = UserManager(logger: dummyLogger, cache: stubCache, database: fakeDatabase, securityHelper: spySecuritySystem, notificationService: mockNotificationService)
        
        // Act
        let result = userManager.authenticate(username: "jane_doe", password: "password123")
        
        // Assert
        XCTAssertTrue(result)
        XCTAssertTrue(spySecuritySystem.verifyAttempt(username: "jane_doe", success: true))
        XCTAssertTrue(mockNotificationService.verifyEmailSent(to: "jane_doe", success: true))
        XCTAssertEqual(stubCache.get("jane_doe"), passwordHash, "User password should be cached after database fetch")
    }
    
    func testAuthenticateWithCacheMissAndInvalidUser() {
        // Arrange
        let dummyLogger = DummyLogger()
        let stubCache = StubCache()
        let fakeDatabase = FakeDatabase() // No users in database
        let spySecuritySystem = SpySecurityHelper()
        let mockNotificationService = MockNotificationService()
        
        let userManager = UserManager(logger: dummyLogger, cache: stubCache, database: fakeDatabase, securityHelper: spySecuritySystem, notificationService: mockNotificationService)
        
        // Act
        let result = userManager.authenticate(username: "unknown_user", password: "password123")
        
        // Assert
        XCTAssertFalse(result)
        XCTAssertTrue(spySecuritySystem.verifyAttempt(username: "unknown_user", success: false))
        XCTAssertTrue(mockNotificationService.verifyEmailSent(to: "unknown_user", success: false))
        XCTAssertNil(stubCache.get("unknown_user"), "Unknown user should not be cached")
    }
    
    func testSecuritySystemRecordsMultipleAttempts() {
        // Arrange
        let dummyLogger = DummyLogger()
        let stubCache = StubCache()
        let fakeDatabase = FakeDatabase()
        let spySecuritySystem = SpySecurityHelper()
        let mockNotificationService = MockNotificationService()
        
        let userManager = UserManager(logger: dummyLogger, cache: stubCache, database: fakeDatabase, securityHelper: spySecuritySystem, notificationService: mockNotificationService)
        
        // Act
        _ = userManager.authenticate(username: "user1", password: "password1")
        _ = userManager.authenticate(username: "user2", password: "password2")
        
        // Assert
        XCTAssertTrue(spySecuritySystem.verifyTotalAttempts(expectedCount: 2))
        XCTAssertTrue(mockNotificationService.verifyTotalEmailsSent(expectedCount: 2))
    }
    
    func testAuthenticateWithCacheMissAndDatabaseError() {
        // Arrange
        let dummyLogger = DummyLogger()
        let stubCache = StubCache()
        let fakeDatabase = FakeDatabase() // No users in database
        let spySecuritySystem = SpySecurityHelper()
        let mockNotificationService = MockNotificationService()
        
        let userManager = UserManager(logger: dummyLogger, cache: stubCache, database: fakeDatabase, securityHelper: spySecuritySystem, notificationService: mockNotificationService)
        
        // Simulate database error by leaving it empty
        
        // Act
        let result = userManager.authenticate(username: "error_user", password: "password123")
        
        // Assert
        XCTAssertFalse(result)
        XCTAssertTrue(spySecuritySystem.verifyAttempt(username: "error_user", success: false))
        XCTAssertTrue(mockNotificationService.verifyEmailSent(to: "error_user", success: false))
        XCTAssertNil(stubCache.get("error_user"), "Failed user should not be cached")
    }
    
    func testAuthenticateCachesPasswordAfterSuccess() {
        // Arrange
        let dummyLogger = DummyLogger()
        let stubCache = StubCache()
        let fakeDatabase = FakeDatabase()
        let spySecuritySystem = SpySecurityHelper()
        let mockNotificationService = MockNotificationService()
        
        let passwordHash = "hashed_password123"
        fakeDatabase.addUser(username: "john_doe", passwordHash: passwordHash)
        
        let userManager = UserManager(logger: dummyLogger, cache: stubCache, database: fakeDatabase, securityHelper: spySecuritySystem, notificationService: mockNotificationService)
        
        // Act
        let result = userManager.authenticate(username: "john_doe", password: "password123")
        
        // Assert
        XCTAssertTrue(result)
        XCTAssertEqual(stubCache.get("john_doe"), passwordHash, "Password should be cached after successful authentication")
    }

    func testAuthenticateCachesAfterDatabaseLookup() {
        // Arrange
        let dummyLogger = DummyLogger()
        let stubCache = StubCache()
        let fakeDatabase = FakeDatabase()
        let spySecuritySystem = SpySecurityHelper()
        let mockNotificationService = MockNotificationService()
        
        let passwordHash = "hashed_password123"
        fakeDatabase.addUser(username: "new_user", passwordHash: passwordHash)
        
        let userManager = UserManager(logger: dummyLogger, cache: stubCache, database: fakeDatabase, securityHelper: spySecuritySystem, notificationService: mockNotificationService)
        
        // Act
        _ = userManager.authenticate(username: "new_user", password: "password123")
        
        // Assert
        XCTAssertEqual(stubCache.get("new_user"), passwordHash)
    }

    func testAuthenticateDoesNotCacheInvalidUser() {
        // Arrange
        let dummyLogger = DummyLogger()
        let stubCache = StubCache()
        let fakeDatabase = FakeDatabase() // Empty database
        let spySecuritySystem = SpySecurityHelper()
        let mockNotificationService = MockNotificationService()
        
        let userManager = UserManager(logger: dummyLogger, cache: stubCache, database: fakeDatabase, securityHelper: spySecuritySystem, notificationService: mockNotificationService)
        
        // Act
        _ = userManager.authenticate(username: "invalid_user", password: "password123")
        
        // Assert
        XCTAssertNil(stubCache.get("invalid_user"))
    }

    func testAuthenticateEmailsAreSentOnFailedAttempts() {
        // Arrange
        let dummyLogger = DummyLogger()
        let stubCache = StubCache()
        let fakeDatabase = FakeDatabase() // No users
        let spySecuritySystem = SpySecurityHelper()
        let mockNotificationService = MockNotificationService()
        
        let userManager = UserManager(logger: dummyLogger, cache: stubCache, database: fakeDatabase, securityHelper: spySecuritySystem, notificationService: mockNotificationService)
        
        // Act
        _ = userManager.authenticate(username: "nonexistent_user", password: "wrong_password")
        
        // Assert
        XCTAssertTrue(mockNotificationService.verifyEmailSent(to: "nonexistent_user", success: false))
    }
    
}

// DummyLogger.swift
class DummyLogger: LoggerService {
    func log(_ message: String) {
        // No-op: This dummy logger does nothing
    }
}

// StubCache.swift
class StubCache: CacheService {
    var storedData: [String: String] = [:]
    
    func get(_ key: String) -> String? {
        return storedData[key] // Simulates cache hit or miss
    }
    
    func set(_ key: String, value: String) {
        storedData[key] = value // Simulates setting a value in the cache
    }
}

// FakeDatabase.swift
class FakeDatabase: DatabaseHelper {
    var users: [String: String] = [:] // Simulated user password storage
    
    func getUserPasswordHash(username: String) -> String? {
        return users[username]
    }
    
    // Helper method to add users to the fake database
    func addUser(username: String, passwordHash: String) {
        users[username] = passwordHash
    }
}

// SpySecurityHelper.swift
class SpySecurityHelper: SecurityHelper {
    var recordedAttempts: [(username: String, success: Bool)] = []
    
    func recordAuthenticationAttempt(username: String, success: Bool) {
        recordedAttempts.append((username, success))
    }
    
    // Helper method to check whether a specific attempt was recorded
    func verifyAttempt(username: String, success: Bool) -> Bool {
        return recordedAttempts.contains { $0.username == username && $0.success == success }
    }
    
    // Helper method to check the total number of attempts
    func verifyTotalAttempts(expectedCount: Int) -> Bool {
        return recordedAttempts.count == expectedCount
    }
}

// MockNotificationService.swift
class MockNotificationService: NotificationService {
    var sentEmails: [(username: String, success: Bool)] = []
    
    func sendRegistrationEmail(username: String, success: Bool) {
        sentEmails.append((username, success))
    }

    func sendAuthenticationEmail(username: String, success: Bool) {
        sentEmails.append((username, success))
    }

    func sendFailedAuthenticationAttemptEmail(username: String, success: Bool) {
        sentEmails.append((username, success))
    }

    // Helper to verify that an email was sent
    func verifyEmailSent(to username: String, success: Bool) -> Bool {
        return sentEmails.contains { $0.username == username && $0.success == success }
    }
    
    // Helper to verify the total number of emails sent
    func verifyTotalEmailsSent(expectedCount: Int) -> Bool {
        return sentEmails.count == expectedCount
    }
}
