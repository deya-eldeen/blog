import Foundation

// NotificationService.swift
protocol NotificationService {
    func sendAuthenticationEmail(username: String, success: Bool)
    func sendRegistrationEmail(username: String, success: Bool)
    func sendFailedAuthenticationAttemptEmail(username: String, success: Bool)
}

// NotificationServiceImpl.swift
class NotificationServiceImpl: NotificationService {
    func sendAuthenticationEmail(username: String, success: Bool) {
        // Here you could implement logic to send an email notification
        print("Sent authentication email to \(username): \(success ? "Success" : "Failure")")
    }

    func sendFailedAuthenticationAttemptEmail(username: String, success: Bool) {
        // Here you could implement logic to send an email notification for a failed attempt
        print("Sent failed authentication attempt email to \(username)")
    }
    
    func sendRegistrationEmail(username: String, success: Bool) {
        // Here you could implement logic to send an email notification for registration
        print("Sent registration email to \(username)")
    }
}
