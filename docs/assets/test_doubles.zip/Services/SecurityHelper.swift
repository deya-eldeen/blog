import Foundation

// SecurityHelper.swift
protocol SecurityHelper {
    func recordAuthenticationAttempt(username: String, success: Bool)
}

// SecurityHelperImpl.swift
class SecurityHelperImpl: SecurityHelper {
    private let logFileURL: URL
    
    init() {
        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        logFileURL = documentsURL.appendingPathComponent("authentication_log.txt")
    }
    
    func recordAuthenticationAttempt(username: String, success: Bool) {
        let logEntry = "\(Date()): Authentication attempt for \(username): \(success ? "Success" : "Failure")\n"
        
        do {
            try logEntry.write(to: logFileURL, atomically: true, encoding: .utf8)
        } catch {
            print("Error writing to log file: \(error)")
        }
    }

    func readAuthenticationAttempts() -> [(username: String, success: Bool)] {
        var attempts: [(username: String, success: Bool)] = []
        
        do {
            let logContents = try String(contentsOf: logFileURL, encoding: .utf8)
            let lines = logContents.split(separator: "\n")
            
            for line in lines {
                // Parse each line to extract the username and success status
                let components = line.split(separator: ":")
                if components.count >= 3 {
                    let username = components[2].split(separator: " ")[3] // Extract the username
                    let successString = components[3].trimmingCharacters(in: .whitespaces) // Extract "Success" or "Failure"
                    let success = successString == "Success"
                    attempts.append((username: String(username), success: success))
                }
            }
        } catch {
            print("Error reading log file: \(error)")
        }
        
        return attempts
    }
}
