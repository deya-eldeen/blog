import Foundation
import os

// Logger.swift
protocol LoggerService {
    func log(_ message: String)
}

// LoggerServiceImpl.swift
class LoggerServiceImpl: LoggerService {
    private let logger = Logger(subsystem: Bundle.main.bundleIdentifier ?? "com.yourapp", category: "default")
    
    func log(_ message: String) {
        logger.log("Log: \(message)")
    }
}
