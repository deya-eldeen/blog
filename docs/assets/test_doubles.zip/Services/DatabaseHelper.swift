import Foundation

// Database.swift
protocol DatabaseHelper {
    func getUserPasswordHash(username: String) -> String?
    func addUser(username: String, passwordHash: String)
}

// DatabaseHelperImpl.swift
class DatabaseHelperImpl: DatabaseHelper {
    private var users: [String: String] = [:] // Simulated user password storage
    
    func getUserPasswordHash(username: String) -> String? {
        return users[username] // Retrieve password hash for the given username
    }
    
    // Helper method to add users to the database for testing purposes
    func addUser(username: String, passwordHash: String) {
        users[username] = passwordHash // Add user to the simulated database
    }
}
